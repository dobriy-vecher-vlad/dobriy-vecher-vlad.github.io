self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "72dceef79213f0e21b4463e2b5337925",
    "url": "./index.html"
  },
  {
    "revision": "cc6fee4a7d34e57a8283",
    "url": "./static/css/2.9fcffd3f.chunk.css"
  },
  {
    "revision": "227606301131d52c5e6f",
    "url": "./static/css/main.8b4a4b59.chunk.css"
  },
  {
    "revision": "cc6fee4a7d34e57a8283",
    "url": "./static/js/2.27964ce2.chunk.js"
  },
  {
    "revision": "e8b0ae1bd2f59a85f300b3c60c50941a",
    "url": "./static/js/2.27964ce2.chunk.js.LICENSE.txt"
  },
  {
    "revision": "227606301131d52c5e6f",
    "url": "./static/js/main.09aac6be.chunk.js"
  },
  {
    "revision": "95aa28ab783283d23935",
    "url": "./static/js/runtime-main.7f50d71e.js"
  }
]);