self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "d01b23052b1f6324e416e986107a044a",
    "url": "./index.html"
  },
  {
    "revision": "2f675fbb72edc888c88e",
    "url": "./static/css/2.1e562f28.chunk.css"
  },
  {
    "revision": "29c21b8d4b30d5c84cd3",
    "url": "./static/css/main.32f88d66.chunk.css"
  },
  {
    "revision": "2f675fbb72edc888c88e",
    "url": "./static/js/2.7c3f832c.chunk.js"
  },
  {
    "revision": "e88a3e95b5364d46e95b35ae8c0dc27d",
    "url": "./static/js/2.7c3f832c.chunk.js.LICENSE.txt"
  },
  {
    "revision": "29c21b8d4b30d5c84cd3",
    "url": "./static/js/main.68d358d2.chunk.js"
  },
  {
    "revision": "95aa28ab783283d23935",
    "url": "./static/js/runtime-main.7f50d71e.js"
  }
]);